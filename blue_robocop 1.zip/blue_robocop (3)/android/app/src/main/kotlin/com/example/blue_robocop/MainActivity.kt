package com.example.blue_robocop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
