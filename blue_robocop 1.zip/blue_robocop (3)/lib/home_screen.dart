import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String address = '00:18:91:D6:8F:0B';
  BluetoothConnection? connection;

  connect() async {
// Some simplest connection :F
    try {
      BluetoothConnection connection =
          await BluetoothConnection.toAddress(address);
      print('Connected to the device');

      if (connection.output.isConnected) {
        while (true) {
          // connection.output.add(Uint8List.fromList(utf8.encode('0')));
          // await Future.delayed(const Duration(seconds: 3));
          connection.output.add(ascii.encode('1'));
          await Future.delayed(const Duration(seconds: 1));
          print('gg');
        }
      }

      connection.input?.listen((Uint8List data) {
        print('Data incoming: ${ascii.decode(data)}');
        connection.output.add(data); // Sending data

        if (ascii.decode(data).contains('!')) {
          connection.finish(); // Closing connection
          print('Disconnecting by local host');
        }
      }).onDone(() {
        print('Disconnected by remote request');
      });
    } catch (exception) {
      print('Cannot connect, exception occured');
    }
  }

  bool isConnected() {
    return connection != null && connection!.isConnected;
  }

  bool isConnectedVar = false;

  Widget arrowsBar({required Function up, required Function down}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          ElevatedButton(
            onPressed: () {
              up();
              print('up');
            },
            child: const Icon(
              Icons.arrow_upward,
              size: 100,
            ),
          ),
          const SizedBox(
            height: 100,
          ),
          ElevatedButton(
            onPressed: () {
              down();
              print('down');
            },
            child: const Icon(
              Icons.arrow_downward,
              size: 100,
            ),
          ),
        ],
      ),
    );
  }

  void moveArmLeft() {
    connection?.output.add(ascii.encode('a'));
  }

  void moveArmRight() {
    connection?.output.add(ascii.encode('d'));
  }

  Widget horizontalArrowBar() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        children: [
          ElevatedButton(
            onPressed: () {
              moveInDirection('a');
            },
            child: const Icon(
              Icons.arrow_left,
              size: 100,
            ),
          ),
          const Spacer(),
          ElevatedButton(
            onPressed: () {
              moveInDirection('d');
            },
            child: const Icon(
              Icons.arrow_right,
              size: 100,
            ),
          ),
        ],
      ),
    );
  }

  Widget eyesBar({Function? switcher}) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ElevatedButton(
            onPressed: () {
              switcher!();
              print('switcher');
            },
            child: const Icon(
              Icons.remove_red_eye,
              size: 100,
            ),
          ),
        ],
      ),
    );
  }

  Widget onOffButton() {
    return ElevatedButton(
      onPressed: () {
        print('ss');
        if (isConnected()) {
          connection!.finish();
          setState(() {
            // connection = null;
            isConnectedVar = false;
            print('Connected');
          });
        } else {
          print('Connecting to the device');
          BluetoothConnection.toAddress(address).then((value) {
            setState(() {
              connection = value;
              isConnectedVar = true;
              print('Connected to the device');
            });
          });
        }
      },
      child: Icon(
        isConnected() ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
        size: 100,
        // color: Colors.blue,
      ),
    );
  }

  moveArmUp() {
    if (connection != null && connection!.isConnected) {
      connection!.output.add(Uint8List.fromList(utf8.encode('w')));
      print('u');
    } else {
      print('Not connected');
    }
  }

  moveArmDown() {
    if (connection != null && connection!.isConnected) {
      connection!.output.add(Uint8List.fromList(utf8.encode('s')));
      print('d');
    } else {
      print('Not connected');
    }
  }

  moveInDirection(String direction) {
    if (connection != null && connection!.isConnected) {
      connection!.output.add(Uint8List.fromList(utf8.encode(direction)));
      print('d');
    } else {
      print('Not connected');
    }
  }

  switchLed() {
    if (connection != null && connection!.isConnected) {
      connection!.output.add(Uint8List.fromList(utf8.encode('l')));
      print('l');
    } else {
      print('Not connected');
    }
  }

  doer() async {
    if (connection != null && connection!.isConnected) {
      while (true) {
        switchLed();
        await Future.delayed(const Duration(seconds: 3));
        print('switcher');
        await Future.delayed(const Duration(seconds: 3));
      }
    }
  }

  @override
  void initState() {
    super.initState();
    BluetoothConnection.toAddress(address).then((value) {
      connection = value;
      isConnectedVar = true;
      print('Connected to the device');
    }).catchError((error) {
      print('Cannot connect, exception occured');
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Blue RoboCop'),
        centerTitle: true,
      ),
      body: SizedBox(
        width: size.width,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          // mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(height: size.height * 0.05),
            eyesBar(switcher: switchLed),
            horizontalArrowBar(),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  ElevatedButton(
                    child: const Icon(
                      Icons.arrow_upward,
                      size: 100,
                    ),
                    onPressed: () {
                      moveInDirection('e');
                    },
                  ),
                  const Spacer(),
                  ElevatedButton(
                    child: const Icon(
                      Icons.arrow_upward,
                      size: 100,
                    ),
                    onPressed: () {
                      moveInDirection('w');
                    },
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  ElevatedButton(
                    child: const Icon(
                      Icons.arrow_downward,
                      size: 100,
                    ),
                    onPressed: () {
                      moveInDirection('q');
                    },
                  ),
                  const Spacer(),
                  ElevatedButton(
                    child: const Icon(
                      Icons.arrow_downward,
                      size: 100,
                    ),
                    onPressed: () {
                      moveInDirection('s');
                    },
                  ),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
